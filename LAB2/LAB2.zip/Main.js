 function activarEstilos() {
     document.body.classList.toggle('styled');
        }
   